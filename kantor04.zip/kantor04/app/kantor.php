<?php
// KONTROLER strony kantoru
require_once dirname(__FILE__).'/../config.php';
// Załaduj Smarty
require_once _ROOT_PATH.'/lib/smarty/libs/Smarty.class.php';

// Funkcja pobierająca parametry
function getParams(&$form){
    $form['amount'] = isset($_REQUEST['amount']) ? $_REQUEST['amount'] : null;
    $form['from_currency'] = isset($_REQUEST['from_currency']) ? $_REQUEST['from_currency'] : null;
    $form['to_currency'] = isset($_REQUEST['to_currency']) ? $_REQUEST['to_currency'] : null;
    $form['exchange_rate'] = isset($_REQUEST['exchange_rate']) ? $_REQUEST['exchange_rate'] : null;
}

// Walidacja parametrów
function validate(&$form, &$infos, &$msgs){
    if (!(isset($form['amount']) && isset($form['from_currency']) && isset($form['to_currency']))) {
        return false;
    }

    // Sprawdzanie, czy kwota jest liczbą
    if ($form['amount'] == "") {
        $msgs[] = 'Nie podano kwoty do wymiany';
    } elseif (!is_numeric($form['amount'])) {
        $msgs[] = 'Kwota nie jest liczbą';
    }

    // Akceptujemy tylko EUR i PLN
    if ($form['from_currency'] != 'EUR' && $form['from_currency'] != 'PLN') {
        $msgs[] = 'Nieobsługiwana waluta źródłowa';
    }
    if ($form['to_currency'] != 'EUR' && $form['to_currency'] != 'PLN') {
        $msgs[] = 'Nieobsługiwana waluta docelowa';
    }

    if (count($msgs) > 0) {
        return false;
    } else {
        $infos[] = 'Przekazano parametry. Wykonuję obliczenia.';
        return true;
    }
}

// Funkcja wykonująca obliczenia
function process(&$form, &$infos, &$msgs, &$result){
    // Przykładowe kursy wymiany EUR <-> PLN
    $exchange_rates = [
        'EUR' => ['PLN' => 4.70], // 1 EUR = 4.70 PLN
        'PLN' => ['EUR' => 0.21]  // 1 PLN = 0.21 EUR
    ];

    // Jeśli waluty są takie same, wynik nie zmienia się
    if ($form['from_currency'] == $form['to_currency']) {
        $result = $form['amount'];
        $infos[] = "Wybrałeś tę samą walutę. Kwota pozostaje bez zmian: {$result} {$form['from_currency']}.";
    } else {
        // Jeśli użytkownik podał ręczny kurs wymiany
        if ($form['exchange_rate'] != "") {
            if (!is_numeric($form['exchange_rate'])) {
                $msgs[] = 'Podany kurs wymiany nie jest liczbą';
            } else {
                $rate = floatval($form['exchange_rate']);
                $result = $form['amount'] * $rate;
                $infos[] = "Przeliczono {$form['amount']} {$form['from_currency']} na {$result} {$form['to_currency']} przy użyciu kursu {$rate}.";
            }
        } else {
            // Przeliczanie z kursami wymiany, jeśli użytkownik nie podał ręcznego kursu
            if (isset($exchange_rates[$form['from_currency']][$form['to_currency']])) {
                $rate = $exchange_rates[$form['from_currency']][$form['to_currency']];
                $result = $form['amount'] * $rate;
                $infos[] = "Przeliczono {$form['amount']} {$form['from_currency']} na {$result} {$form['to_currency']} przy użyciu kursu rynkowego {$rate}.";
            } else {
                $msgs[] = 'Nieobsługiwane waluty';
            }
        }
    }
}

// Inicjalizacja zmiennych
$form = null;
$infos = array();
$messages = array();
$result = null;

getParams($form);
if (validate($form, $infos, $messages)){
    process($form, $infos, $messages, $result);
}

// Przygotowanie danych dla szablonu
$smarty = new Smarty\Smarty();
$smarty->assign('app_url', _APP_URL);
$smarty->assign('root_path', _ROOT_PATH);
$smarty->assign('page_title', 'Kantor Helios'); // Zmiana tytułu na Kantor Helios
$smarty->assign('page_description', 'Profesjonalne przeliczanie walut w Kantorze Helios'); // Zmiana opisu
$smarty->assign('page_header', 'Kantor Helios'); // Zmiana nagłówka na Kantor Helios

$smarty->assign('form', $form);
$smarty->assign('result', $result);
$smarty->assign('messages', $messages);
$smarty->assign('infos', $infos);

// Wywołanie szablonu
$smarty->display(_ROOT_PATH.'/app/calc.html');
