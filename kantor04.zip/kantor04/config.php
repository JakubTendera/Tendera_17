<?php
// Sprawdzenie, czy stała już jest zdefiniowana
if (!defined('_SERVER_NAME')) {
    define('_SERVER_NAME', 'localhost:80');
}

if (!defined('_SERVER_URL')) {
    define('_SERVER_URL', 'http://'._SERVER_NAME);
}

if (!defined('_APP_ROOT')) {
    define('_APP_ROOT', '/kantor04');
}

if (!defined('_APP_URL')) {
    define('_APP_URL', _SERVER_URL._APP_ROOT);
}

if (!defined('_ROOT_PATH')) {
    define('_ROOT_PATH', dirname(__FILE__));  // Określenie katalogu głównego aplikacji
}
?>
