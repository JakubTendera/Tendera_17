<?php
// Ścieżka do katalogu z plikami aplikacji
define('_ROOT_PATH', dirname(__FILE__));  // Określamy katalog główny aplikacji

// Przekierowanie do pliku calc.php (jeśli chcesz, aby ten plik był wywoływany bezpośrednio)
include _ROOT_PATH . '/app/kantor.php';
?>
