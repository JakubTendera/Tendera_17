<?php
/* Smarty version 5.4.1, created on 2025-01-29 12:51:41
  from 'file:C:\xampp\htdocs\kantor04/app/calc.html' */

/* @var \Smarty\Template $_smarty_tpl */
if ($_smarty_tpl->getCompiled()->isFresh($_smarty_tpl, array (
  'version' => '5.4.1',
  'unifunc' => 'content_679a164d241521_15200973',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '28e35f4a459e55c5a928cd5d218f968139f2542c' => 
    array (
      0 => 'C:\\xampp\\htdocs\\kantor04/app/calc.html',
      1 => 1737979256,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
))) {
function content_679a164d241521_15200973 (\Smarty\Template $_smarty_tpl) {
$_smarty_current_dir = 'C:\\xampp\\htdocs\\kantor04\\app';
$_smarty_tpl->getInheritance()->init($_smarty_tpl, true);
?>


<?php 
$_smarty_tpl->getInheritance()->instanceBlock($_smarty_tpl, 'Block_1023403599679a164ce3d770_74743695', 'footer');
?>


<?php 
$_smarty_tpl->getInheritance()->instanceBlock($_smarty_tpl, 'Block_384185920679a164cf2d972_19943564', 'content');
?>

<?php $_smarty_tpl->getInheritance()->endChild($_smarty_tpl, "../templates/main.html", $_smarty_current_dir);
}
/* {block 'footer'} */
class Block_1023403599679a164ce3d770_74743695 extends \Smarty\Runtime\Block
{
public function callBlock(\Smarty\Template $_smarty_tpl) {
$_smarty_current_dir = 'C:\\xampp\\htdocs\\kantor04\\app';
?>
przykładowa treść stopki wpisana do szablonu głównego z szablonu kantoru Helios<?php
}
}
/* {/block 'footer'} */
/* {block 'content'} */
class Block_384185920679a164cf2d972_19943564 extends \Smarty\Runtime\Block
{
public function callBlock(\Smarty\Template $_smarty_tpl) {
$_smarty_current_dir = 'C:\\xampp\\htdocs\\kantor04\\app';
?>


<h3>Kantor Helios: EUR <-> PLN</h3> <!-- Zmieniony nagłówek na Kantor Helios -->

<form class="pure-form pure-form-stacked" action="<?php echo $_smarty_tpl->getValue('app_url');?>
/app/kantor.php" method="post">
    <fieldset>
        <label for="amount">Kwota</label>
        <input id="amount" type="text" placeholder="Kwota do wymiany" name="amount" value="<?php echo $_smarty_tpl->getValue('form')['amount'];?>
">

        <label for="from_currency">Z waluty</label>
        <select id="from_currency" name="from_currency">
            <option value="EUR" <?php if ($_smarty_tpl->getValue('form')['from_currency'] == 'EUR') {?>selected<?php }?>>EUR</option>
            <option value="PLN" <?php if ($_smarty_tpl->getValue('form')['from_currency'] == 'PLN') {?>selected<?php }?>>PLN</option>
        </select>

        <label for="to_currency">Na walutę</label>
        <select id="to_currency" name="to_currency">
            <option value="EUR" <?php if ($_smarty_tpl->getValue('form')['to_currency'] == 'EUR') {?>selected<?php }?>>EUR</option>
            <option value="PLN" <?php if ($_smarty_tpl->getValue('form')['to_currency'] == 'PLN') {?>selected<?php }?>>PLN</option>
        </select>

        <label for="exchange_rate">Ręcznie wpisany kurs wymiany (jeśli znasz kurs)</label>
        <input id="exchange_rate" type="text" placeholder="Wpisz kurs wymiany" name="exchange_rate" value="<?php echo $_smarty_tpl->getValue('form')['exchange_rate'];?>
">
    </fieldset>
    <button type="submit" class="pure-button pure-button-primary">Przelicz</button>
</form>

<div class="messages">
    <?php if ((null !== ($_smarty_tpl->getValue('messages') ?? null))) {?>
        <?php if ($_smarty_tpl->getSmarty()->getModifierCallback('count')($_smarty_tpl->getValue('messages')) > 0) {?>
            <h4>Wystąpiły błędy: </h4>
            <ol class="err">
                <?php
$_from = $_smarty_tpl->getSmarty()->getRuntime('Foreach')->init($_smarty_tpl, $_smarty_tpl->getValue('messages'), 'msg');
$foreach0DoElse = true;
foreach ($_from ?? [] as $_smarty_tpl->getVariable('msg')->value) {
$foreach0DoElse = false;
?>
                    <li><?php echo $_smarty_tpl->getValue('msg');?>
</li>
                <?php
}
$_smarty_tpl->getSmarty()->getRuntime('Foreach')->restore($_smarty_tpl, 1);?>
            </ol>
        <?php }?>
    <?php }?>

    <?php if ((null !== ($_smarty_tpl->getValue('infos') ?? null))) {?>
        <?php if ($_smarty_tpl->getSmarty()->getModifierCallback('count')($_smarty_tpl->getValue('infos')) > 0) {?>
            <h4>Informacje: </h4>
            <ol class="inf">
                <?php
$_from = $_smarty_tpl->getSmarty()->getRuntime('Foreach')->init($_smarty_tpl, $_smarty_tpl->getValue('infos'), 'msg');
$foreach1DoElse = true;
foreach ($_from ?? [] as $_smarty_tpl->getVariable('msg')->value) {
$foreach1DoElse = false;
?>
                    <li><?php echo $_smarty_tpl->getValue('msg');?>
</li>
                <?php
}
$_smarty_tpl->getSmarty()->getRuntime('Foreach')->restore($_smarty_tpl, 1);?>
            </ol>
        <?php }?>
    <?php }?>

    <?php if ((null !== ($_smarty_tpl->getValue('result') ?? null))) {?>
        <h4>Wynik wymiany</h4>
        <p class="res"><?php echo $_smarty_tpl->getValue('result');?>
</p>
    <?php }?>
</div>

<?php
}
}
/* {/block 'content'} */
}
